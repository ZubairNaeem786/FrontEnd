const AdminCtrl = require("./admin.ctrl");

module.exports = {
  AdminCtrl,
};
