const Reducer = (state, action) => {
  switch (action.type) {
    // case "SET_lists":
    //   return {
    //     ...state,
    //     lists: action.payload,
    //   };
    case "ADD_POST":
      const data = state.lists.push(action.payload);
      return {
        ...state,
        data,
      };

    case "REMOVE_POST":
      //  const data=state.lists.filter((list)=>list.id!==action)
      return {
        ...state,
        lists: state.lists.filter((list) => list.id !== action.payload),
      };
    case "SET_ERROR":
      return {
        ...state,
        error: action.payload,
      };
    default:
      return state;
  }
};

export default Reducer;
