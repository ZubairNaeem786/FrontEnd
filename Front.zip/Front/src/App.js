import { Switch } from "react-router-dom";
import Routes from "./Routes";
import "bootstrap/dist/css/bootstrap.min.css";
import Store from "./store";
function App() {
  return (
    <Store>
      <Switch>
        <Routes />
      </Switch>
    </Store>
  );
}

export default App;
