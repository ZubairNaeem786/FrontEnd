const HttpStatus = require("../HttpStatus");

const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const config = require("../config");

const EXPIRES_IN_MINUTES = "1440m"; // expires in 24 hours

module.exports = {
  insertAdmin: (req, res) => {
    const body = req.body;

    if (!body) {
      return res.status(HttpStatus.unauthorized).json({
        success: false,
        error: "You must provide an admin",
      });
    }
  },
  authenticate: (req, res) => {},
};
