import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import ListTask from "./Front/ListTask";
import DeleteBulk from "./Front/DeleteBulk";
import CreateTask from "./Front/CreateTask";
function Routes() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={ListTask} />
        <Route path="/createTask" component={CreateTask} />
        <Route path="/deleteBulk" component={DeleteBulk} />
      </Switch>
    </Router>
  );
}
export default Routes;
