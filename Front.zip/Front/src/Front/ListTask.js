import { React, useState, Fragment, useContext, useEffect } from "react";
import { useHistory } from "react-router";
import { Card, Button } from "react-bootstrap";
import { Context } from "../store";
function ListTask() {
  const history = useHistory();
  const [state, dispatch] = useContext(Context);
  // const [data, setData] = useState("");
  const movetoCreate = () => {
    history.push("/createTask");
  };

  const movetodeleteBulk = () => {
    history.push("/deleteBulk");
  };
  useEffect(() => {
    console.log(state.lists);
    // setData(state.lists);
  }, []);
  return (
    <Fragment>
      <div
        style={{
          position: "fixed",
          left: "50%",
          top: "30%",
          transform: "translate(-50%, -50%)",
        }}
      >
        <h1 style={{ textAlign: "center" }}>All Items</h1>
        {state.lists.map((obj, i) => {
          return (
            <Card
              style={{
                width: "18rem",
                textAlign: "center",
                marginTop: "15px",
                marginBottom: "10px",
              }}
              key={obj.id}
            >
              <h3>{obj.name}</h3>
            </Card>
          );
        })}

        <Button
          variant="secondary"
          onClick={() => {
            movetoCreate();
          }}
        >
          Add list Item
        </Button>

        <Button
          variant="secondary"
          onClick={() => {
            movetodeleteBulk();
          }}
          style={{ marginLeft: "15px" }}
        >
          Remove Bulk
        </Button>
      </div>
    </Fragment>
  );
}

export default ListTask;
