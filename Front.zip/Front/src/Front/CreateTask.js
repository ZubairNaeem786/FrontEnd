import { React, useState, useContext } from "react";
import { useHistory } from "react-router";
import { Card, Button } from "react-bootstrap";
import { Context } from "../store";
import { v4 as uuidv4 } from "uuid";
function CreateTask() {
  const [name, setName] = useState("");
  const [value, setValue] = useState("");
  const [state, dispatch] = useContext(Context);
  const history = useHistory();
  const setData = (e) => {
    const { name, value } = e.target;
    if (name === "name") {
      setName(value);
    }
    if (name === "value") {
      setValue(value);
    }
  };

  const addData = () => {
    const id = uuidv4();
    const data = {
      id: id,
      name: name,
      value: value,
    };
    const key = dispatch({ type: "ADD_POST", payload: data });
    history.push("/");
  };
  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top: "30%",
        transform: "translate(-50%, -50%)",
      }}
    >
      <div className="form-group">
        <label htmlFor="formGroupExampleInput">List Name</label>
        <input
          type="text"
          className="form-control"
          id="formGroupExampleInput"
          name="name"
          defaultValue={name}
          onChange={setData}
        />

        <label htmlFor="formGroupExampleInput">List Value</label>
        <input
          type="text"
          className="form-control"
          id="formGroupExampleInput"
          name="value"
          defaultValue={value}
          onChange={setData}
        />
      </div>
      <Button onClick={addData}>Insert</Button>
    </div>
  );
}

export default CreateTask;
