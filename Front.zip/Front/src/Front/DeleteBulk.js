import { React, useState, Fragment, useContext, useEffect } from "react";
import { useHistory } from "react-router";
import { Card, Button } from "react-bootstrap";
import { Context } from "../store";
function DeleteBulk() {
  const history = useHistory();
  const [state, dispatch] = useContext(Context);
  const [ids, setIds] = useState([]);
  const checkBoxDelete = (id) => {
    let data = ids;
    let found = false;
    if (data.length) {
      data.map((obj) => {
        if (obj === id) {
          found = true;
        }
      });
      if (found) {
        data = data.filter((list) => list !== id);
        console.log("FilterData", data);
        // setIds(data);
      } else {
        data.push(id);
        // setIds(data);
      }
    } else {
      data.push(id);
      // setIds(data);
    }
    setIds(data);
  };
  const deleteAll = () => {
    console.log(ids);
    ids.map((obj) => {
      dispatch({ type: "REMOVE_POST", payload: obj });
    });
    history.push("/");
  };
  return (
    <Fragment>
      <div
        style={{
          position: "fixed",
          left: "50%",
          top: "30%",
          transform: "translate(-50%, -50%)",
        }}
        className="custom-control custom-checkbox"
      >
        <h1 style={{ textAlign: "center" }}>Remove Bulk</h1>
        {state.lists.map((obj, i) => {
          return (
            <Card
              style={{
                width: "18rem",
                textAlign: "center",
                marginTop: "15px",
                marginBottom: "10px",
              }}
              key={obj.id}
            >
              <input
                type="checkbox"
                onChange={() => {
                  checkBoxDelete(obj.id);
                }}
              />
              <h3>{obj.name}</h3>
              <h6>{obj.value}</h6>
            </Card>
          );
        })}
        <Button onClick={deleteAll}>Delete</Button>
      </div>
    </Fragment>
  );
}

export default DeleteBulk;
